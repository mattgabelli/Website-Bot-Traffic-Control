# ieuk-task-2025
This repo contains the log file for completing the 2025 IEUK Engineering task! The log file is too big to view in browser so you'll need to download it to your local machine. 

## Download Task
### Via Github UI 
https://github.com/user-attachments/assets/81972137-bf32-42c1-bc7d-dc65a0b9398f

### Via Git
You'll need to install Git and the Git LFS extension (which can be found [here](https://git-lfs.com/)). If you're unfamiliar with Git, I wouldn't worry about this—just download the log file via the UI. Using Git is not part of the task, so it's not worth spending too much time on it.
